RSAEuro Version 1.04.

RSAEuro-1.04.tar.gz:  UNIX Tape Archive Version
RSAEuro-1.04d.zip:  Zip File Version (Docs)
RSAEuro-1.04s.zip:  Zip file Version (Source Code)
SHSFix.zip:  Fix for SHSUpdate problem in SHSC.C