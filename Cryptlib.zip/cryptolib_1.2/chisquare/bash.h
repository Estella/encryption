/*
 *	suite of randomness tests
 *	D. P. Mitchell  91/10/26.
 */
#include <stdio.h>
#include <assert.h>

extern double chi();
extern double erf(), gamma(), exp(), sqrt(), log(), pow();
