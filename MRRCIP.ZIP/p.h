#ifdef __STDC__
# define	P(s) s
#else
# define P(s) ()
#endif
#endif
