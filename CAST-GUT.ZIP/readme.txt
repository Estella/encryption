The following is my implementation of CAST-128 for anyone who may be
interested in the code.  This posting consists of three files:

  cast128.c     -- CAST-128 code
  cast128.h     -- CAST-128 Header file
  cast128s.h    -- S-boxes (zipped because it's just a lot of numbers)

See the comments at the start of the .C file for more information.

Peter.