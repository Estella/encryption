public class Harness
{
        public static void main(String args[])
        {
               Vlpoint.vlSelfTest(1000);
               Gfpoint.gfSelfTest(500);
               Ecpoint.ecSelfTest(25);
                SHA1.SHAselfTest();
        }
}
